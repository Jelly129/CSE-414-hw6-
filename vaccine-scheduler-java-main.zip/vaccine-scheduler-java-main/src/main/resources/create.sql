CREATE TABLE Patients (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);
CREATE TABLE Caregivers (
    Username varchar(255),
    Salt BINARY(16),
    Hash BINARY(16),
    PRIMARY KEY (Username)
);

CREATE TABLE Availabilities (
    Time date,
    Username varchar(255) REFERENCES Caregivers,
    PRIMARY KEY (Time, Username)
);

CREATE TABLE Vaccines (
    Name varchar(255),
    Doses int,
    PRIMARY KEY (Name)
);


CREATE TABLE Reservations (
    AppointmentID INT PRIMARY KEY,
    PatientUsername VARCHAR(255),
    CaregiverUsername VARCHAR(255),
    VaccineName VARCHAR(255),
    Time DATE,
    FOREIGN KEY (PatientUsername) REFERENCES Patients(Username),
    FOREIGN KEY (CaregiverUsername) REFERENCES Caregivers(Username),
    FOREIGN KEY (Time, CaregiverUsername) REFERENCES Availabilities(Time, Username),
    FOREIGN KEY (VaccineName) REFERENCES Vaccines(Name),
    UNIQUE (Time, CaregiverUsername)
);